for number in range(10):
    print(10 - number)