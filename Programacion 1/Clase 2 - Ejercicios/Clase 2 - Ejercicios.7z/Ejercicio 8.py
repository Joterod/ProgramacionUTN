numero = int(input("Ingrese un número para ver su tabla de multiplicar"))
for i in range(1,10):
    print(f"{numero} * {i} = {numero*i}")