for number in range(10):
    print(number + 1)