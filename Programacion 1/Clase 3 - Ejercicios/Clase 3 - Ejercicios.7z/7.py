"""
7. Crear una función qué se encargue de multiplicar dos números, la misma debe recibir como parámetro dos números y retornar el resultado.
"""

def multiplicar_numeros(primer_numero, segundo_numero):
    """
    Recibe 2 números y los multiplica
    primer_numero = int
    segundo_numero = int
    """
    return primer_numero * segundo_numero

